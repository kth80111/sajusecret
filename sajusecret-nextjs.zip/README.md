# Sajusecret 무료운세 SaaS

1. npm install
2. npm run dev
3. http://localhost:3000 접속
